from flask import Flask, render_template, request
import random

app = Flask(__name__)

# Page d'accueil
@app.route("/")
def index():
    return render_template("index.html")

# Jeu 1 : Valeur du nom
@app.route("/valeur", methods=["GET", "POST"])
def valeur_nom():
    valeur = None
    if request.method == "POST":
        nom = request.form["nom"]
        valeur = sum(ord(c) for c in nom) % 500  # Valeur entre 0 et 500
    return render_template("valeur_nom.html", valeur=valeur)

# Jeu 2 : Quiz manga
@app.route("/quiz", methods=["GET", "POST"])
def quiz():
    questions = {
        "Qui est le frère de Itachi ?": "Sasuke",
        "Dans quel manga trouve-t-on Luffy ?": "One Piece",
        "Quel est le prénom de Gojo ?": "Satoru"
    }
    score = None
    if request.method == "POST":
        score = 0
        for q, r in questions.items():
            if request.form.get(q) and request.form[q].strip().lower() == r.lower():
                score += 1
    return render_template("quiz.html", questions=questions, score=score)

# Jeu 3 : Générateur de surnom manga
@app.route("/surnom", methods=["GET", "POST"])
def surnom():
    surnom = None
    suffixes = ["-kun", "-chan", "-senpai", "-sama", "-sensei"]
    if request.method == "POST":
        nom = request.form["nom"]
        surnom = nom.capitalize() + random.choice(suffixes)
    return render_template("surnom.html", surnom=surnom)

# Jeu 4 : Devine le manga
@app.route("/devine")
def devine_manga():
    return render_template("devine_manga.html")

# Jeu 5 : Chiffre de chance
@app.route("/chance")
def chiffre_chance():
    chiffre = random.randint(1, 100)
    return render_template("chiffre_chance.html", chiffre=chiffre)

# Jeu 6 : Anime shuffle
@app.route("/shuffle")
def anime_shuffle():
    animes = ["Naruto", "One Piece", "Bleach", "Jujutsu Kaisen", "Demon Slayer"]
    return render_template("anime_shuffle.html", anime=random.choice(animes))

# Jeu 7 : Personnage aléatoire
@app.route("/personnage")
def personnage_random():
    persos = ["Naruto", "Luffy", "Goku", "Ichigo", "Gojo", "Tanjiro"]
    return render_template("personnage_random.html", perso=random.choice(persos))

# Jeu 8 : Citation manga
@app.route("/citation")
def citation_manga():
    citations = [
        "Un vrai ninja endure la douleur. – Naruto",
        "Je deviendrai le roi des pirates ! – Luffy",
        "Tu n'es pas assez fort pour me battre. – Gojo"
    ]
    return render_template("citation_manga.html", citation=random.choice(citations))

# Jeu 9 : Duel manga
@app.route("/duel")
def duel_manga():
    persos = ["Naruto", "Luffy", "Goku", "Gojo", "Sasuke", "Ichigo"]
    p1, p2 = random.sample(persos, 2)
    return render_template("duel_manga.html", p1=p1, p2=p2)

if __name__ == "__main__":
    app.run(debug=True)